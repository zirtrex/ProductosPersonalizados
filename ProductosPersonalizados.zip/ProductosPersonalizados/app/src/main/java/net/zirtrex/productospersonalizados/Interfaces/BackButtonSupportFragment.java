package net.zirtrex.productospersonalizados.Interfaces;

public interface BackButtonSupportFragment {
    // return true if your fragment has consumed
    // the back press event, false if you didn't
    boolean onBackPressed();
}
