package net.zirtrex.productospersonalizados.Interfaces;

public interface OnFragmentInteractionListener {

    void saveMonto(Double monto);

    void updateNotificationsBadge(Integer count);

    Double getMonto();

}
