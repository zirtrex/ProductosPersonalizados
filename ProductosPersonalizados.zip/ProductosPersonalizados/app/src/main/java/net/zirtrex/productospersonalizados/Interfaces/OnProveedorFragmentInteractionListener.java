package net.zirtrex.productospersonalizados.Interfaces;

public interface OnProveedorFragmentInteractionListener {

}
